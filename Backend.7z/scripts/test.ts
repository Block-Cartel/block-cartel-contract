// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
import { ethers } from "hardhat";

async function main() {

    const [deployer] = await ethers.getSigners();

    console.log('Deploying contracts with the account: ' + deployer.address + '\n');



    // // ==================== Deploy Contracts ====================

    const sMDAO = await ethers.getContractFactory("sMDAO");
    const smdao = await sMDAO.attach(
        '0x7b6C8647AaB75b7d5Bd8072009A04108a227d5aD'
    );

    const MDAOStaking = await ethers.getContractFactory("MDAOStaking");
    const mdaoStaking = await MDAOStaking.attach(
        '0x0EFe77205E226406Ae44731934B4e6C15B1c3e71'
    );

    const TaxHelper = await ethers.getContractFactory("TaxHelper");
    const taxHelper = await TaxHelper.attach(
        '0xC2f667E6dC42Bf240f8705e88363Fccf44A0062e'
    );

    const StakingHelper = await ethers.getContractFactory("StakingHelper");
    const stakingHelper = await StakingHelper.attach(
        '0xC71F0159E4fA85373002A0B1E649c9B71b9a549F'
    );

    const MDAO = await ethers.getContractFactory("MDAO");
    const mdao = await MDAO.attach(
        '0x3fc47290e7842AF0119ebc2e52b1AF20004061bF'
    );




    await mdao.approve(stakingHelper.address, ethers.utils.parseUnits("1000000000", "gwei").toString());
    await smdao.approve(mdaoStaking.address, ethers.utils.parseUnits("1000000000", "gwei").toString());

    console.log('approved')

    // for (let i = 1; i < 390; i ++) {
    //     await stakingHelper.stake(ethers.utils.parseUnits("0", "gwei").toString(), deployer.address, true);
    //     console.log('staked', i);
    // }

    await stakingHelper.stake(ethers.utils.parseUnits("1000", "gwei").toString(), deployer.address, true);
    console.log('staked', 1);

    console.log(await taxHelper.getTaxStats());

    await mdaoStaking.unstake(deployer.address, ethers.utils.parseUnits("100", "gwei").toString(), true, true);
    console.log('unstaked');

    console.log(await taxHelper.getTaxStats());

    await mdaoStaking.unstake(deployer.address, ethers.utils.parseUnits("100", "gwei").toString(), true, true);
    console.log('unstaked');

    console.log(await taxHelper.getTaxStats());

    await stakingHelper.stake(ethers.utils.parseUnits("1000", "gwei").toString(), deployer.address, true);
    console.log('staked', 2);

    console.log(await taxHelper.getTaxStats());

    await mdaoStaking.unstake(deployer.address, ethers.utils.parseUnits("100", "gwei").toString(), true, true);
    console.log('unstaked');

    console.log(await taxHelper.getTaxStats());

    await mdaoStaking.unstake(deployer.address, ethers.utils.parseUnits("100", "gwei").toString(), true, true);
    console.log('unstaked');

    console.log(await taxHelper.getTaxStats());

}

main()
    .then(() => process.exit())
    .catch(error => {
        console.error(error);
        process.exit(1);
});