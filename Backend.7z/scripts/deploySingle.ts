// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
import { ethers } from "hardhat";

async function main() {

    const [deployer] = await ethers.getSigners();

    console.log('Deploying contracts with the account: ' + deployer.address + '\n');

    const MDAO = await ethers.getContractFactory("MDAO");
    const mdao = await MDAO.attach(
        '0xC9fBE4ed7Abd7F3F2b32C6F42bc68b58933acB9b'
    );

    await mdao.approve('0xd7E0D33997149b1f3039C07A3Bd50a3B2FeFb20f', '100000000000000000000000000');
}

main()
    .then(() => process.exit())
    .catch(error => {
        console.error(error);
        process.exit(1);
});
