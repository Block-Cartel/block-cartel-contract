// We require the Hardhat Runtime Environment explicitly here. This is optional
// but useful for running the script in a standalone fashion through `node <script>`.
//
// When running the script with `npx hardhat run <script>` you'll find the Hardhat
// Runtime Environment's members available in the global scope.
import { ethers } from "hardhat";

async function main() {

    const [deployer] = await ethers.getSigners();

    console.log('Deploying contracts with the account: ' + deployer.address + '\n');

    const epochLengthInBlocks = '300'; //550 

    const firstEpochBlock = '23087131'; //9505000

    const firstEpochNumber = '1';

    const initialIndex = '7675210820';

    const treasuryTimelock = '0';

    const initialRewardRate = '1';

    const warmupPeriod = "0";

    // CV for DAI Bond
    const daiBondBCV = '369';

    // Term is fiexd or not
    const fixedTerm = true;

    // Bond vesting length in blocks. 216000 ~ 5 days
    const bondVestingLength = '1';

    const expiration = '1';

    const conclusion = '33083342';

    // Min bond price
    const minBondPrice = '10';

    // Max bond payout
    const maxBondPayout = '50';

    // Max debt bond can take on
    const maxBondDebt = '1000000000000000';

    // Initial Bond debt
    const intialBondDebt = '0';

    const zeroAddress = '0x0000000000000000000000000000000000000000';

    const initFeReward = 0;

    const initCapacity = "100000000000000000000000000000000";

    // Addresses for distributing tax fee

    // const LAMBO_ADDRESS = '0x3A612F4f52B7d8eB9309D3F51f60b7E248A2aBC0';
    // const LIQUIDITY_POOL_ADDRESS = '0xCf5Ea9152B8ebD1C36D9C353937263306F1558Fe';
    // const CHARITY_ADDRESS = '0x89b2555eBBF3bf486226Ae4A3e9111508Ec442b9';
    // const BLACK_HOLE_ADDRESS = '0xB56DCc25abee2E518084ACBfF53832Ee7D6EE85d';
    // const MARKETING_ADDRESS = '0xF55400379b941f71f06E322D8ACE3a2AC69BE5dA';
    const TEAM_ADDRESS = '0x561b51f571a270ce31936EA159bc80e9B4C33261';
    // const DAO_COMMUNITY_ADDRESS = '0xBa4370807FdC38cD4C10e2bE1A1D0ce05Aad6740';

    // Deploy Tested Dai Stablecoin
    const TDAI = await ethers.getContractFactory('TDAI');
    const tdai = await TDAI.deploy(0);

    // mint TDAI for deployer
    await tdai.mint(deployer.address, '30000000000000000000000000'); // 3.000,000

    console.log('Deployed TDAI contract\n');


    // Deploy BLOCKS Authority
    const BLOCKSAuthority = await ethers.getContractFactory('BLOCKSAuthority');
    const blocksAuthority = await BLOCKSAuthority.deploy(deployer.address, deployer.address, deployer.address, deployer.address);

    console.log('Deployed BLOCKSAuthority contract\n');



    // Deploy BLOCKS
    const BLOCKS = await ethers.getContractFactory('BLOCKS');
    const blocks = await BLOCKS.deploy(blocksAuthority.address, TEAM_ADDRESS);

    console.log('Deployed BLOCKS contract\n');


    // Deploy Bonding Calculator
    const BLOCKSBondingCalculator = await ethers.getContractFactory('BLOCKSBondingCalculator');
    const blocksBondingCalculator = await BLOCKSBondingCalculator.deploy(blocks.address);

    console.log('Deployed BLOCKSBondingCalculator contract\n');



    // Deploy Staked BLOCKS
    const sBLOCKS = await ethers.getContractFactory('sBLOCKS');
    const sblocks = await sBLOCKS.deploy();

    // Initialize sOHM and set the index

    await sblocks.setIndex(initialIndex); // TODO

    console.log('Deployed Staked BLOCKS contract\n');



    // Deploy Wrapped sBLOCKS
    // const wsBLOCKS = await ethers.getContractFactory('wsBLOCKS');
    // const wsblocks = await wsBLOCKS.deploy(sblocks.address);

    // console.log('Deployed Wrapped sBLOCKS contract\n');



    // Deploy Staking
    const BLOCKSStaking = await ethers.getContractFactory('BLOCKSStaking');
    const blocksStaking = await BLOCKSStaking.deploy(blocks.address, sblocks.address, epochLengthInBlocks, firstEpochNumber, firstEpochBlock, blocksAuthority.address);

    console.log('Deployed BLOCKSStaking contract\n');



    // Deploy Staking Helper
    const StakingHelper = await ethers.getContractFactory('StakingHelper');
    const stakingHelper = await StakingHelper.deploy(blocksStaking.address, blocks.address);

    console.log('Deployed Staking Helper contract\n');



    // Deploy Staking Warmup
    const StakingWarmup = await ethers.getContractFactory('StakingWarmup');
    const stakingWarmup = await StakingWarmup.deploy(blocksStaking.address, sblocks.address);

    console.log('Deployed Staking Warmup contract\n');



    // Deploy Staked BLOCKS
    const BLOCKSTreasury = await ethers.getContractFactory('BLOCKSTreasury');
    const blocksTreasury = await BLOCKSTreasury.deploy(blocks.address, treasuryTimelock, blocksAuthority.address);

    // Set treasury for BLOCKS token
    await blocksAuthority.pushVault(blocksTreasury.address, true);

    // TODO: These two functions are causing a revert
    // Deposit 9,000,000 DAI to treasury, 600,000 OHM gets minted to deployer and 8,400,000 are in treasury as excesss reserves
    // await blocksTreasury.deposit("9000000000000000000000000", tdai.address, "8400000000000000");

    console.log('Deployed BLOCKSTreasury contract\n');
 
    // Deploy Staking Distributor
    const Distributor = await ethers.getContractFactory('Distributor');
    const distributor = await Distributor.deploy(blocksTreasury.address, blocks.address, blocksStaking.address, blocksAuthority.address);

    console.log('Deployed Distributor contract\n');



    // Deploy Bond Depository
    const BLOCKSBondDepository = await ethers.getContractFactory('BLOCKSBondDepository');
    const blocksBondDepository = await BLOCKSBondDepository.deploy(blocks.address, blocksTreasury.address, blocksAuthority.address);

    console.log('Deployed BLOCKSBondDepository contract\n');



    // Deploy Bond Teller
    const BondTeller = await ethers.getContractFactory('BondTeller');
    const bondTeller = await BondTeller.deploy(blocksBondDepository.address, stakingHelper.address, blocksTreasury.address, blocks.address, sblocks.address, blocksAuthority.address);

    console.log('Deployed BondTeller contract\n');







    console.log( "============ Contract Addresses ============\n" );

    var blocksAuthorityLog = { Label: "BLOCKS Authority", Info: blocksAuthority.address };

    var tdaiLog = { Label: "Tested Dai Stablecoin", Info: tdai.address };
    var blocksLog = { Label: "BLOCKS", Info: blocks.address };
    var sblocksLog = { Label: "Staked BLOCKS ", Info: sblocks.address };
    // var wsblocksLog = { Label: "Wrapped BLOCKS", Info: wsblocks.address };

    var blocksStakingLog = { Label: "BLOCKS Staking", Info: blocksStaking.address };
    var distributorLog = { Label: "Staking Distributor", Info: distributor.address };
    var stakingWarmupLog = { Label: "Staking Warmup", Info: stakingWarmup.address };
    var stakingHelperLog = { Label: "Staking Helper", Info: stakingHelper.address };
    var blocksTreasuryLog = { Label: "BLOCKS Treasury", Info: blocksTreasury.address };
    var blocksBondDepositoryLog = { Label: "BLOCKS Bond Deposityr", Info: blocksBondDepository.address };
    var bondTellerLog = { Label: "BLOCKS Bond Teller", Info: bondTeller.address };
    var blocksBondingCalculatorLog = { Label: "BLOCKS Bonding Calculator", Info: blocksBondingCalculator.address };

    // var UserHelperLog = { Label: "User Helper", Info: userHelper.address };



    console.table([
        tdaiLog,
        blocksLog,
        sblocksLog,
        // wsblocksLog,
       
        blocksStakingLog,
        distributorLog,
        stakingWarmupLog,
        stakingHelperLog,
       
        blocksTreasuryLog,
        blocksBondDepositoryLog,
        bondTellerLog,

        // UserHelperLog,
        blocksAuthorityLog,
        blocksBondingCalculatorLog
    ]);

    // Setup Contracts
    await sblocks.initialize(blocksStaking.address, blocksTreasury.address);

    console.log('sBLOCKS initialized\n');



    await blocksStaking.setContract('0', distributor.address);

    console.log('BLOCKS Staking set Distributor\n');



    await blocksStaking.setContract('1', stakingWarmup.address);

    console.log('BLOCKS Staking set Staking Warmup\n');



    await blocksStaking.setWarmupLength(warmupPeriod);

    console.log('BLOCKS Staking set Warmup Length\n');



    // Add staking contract as distributor recipient
    await distributor.addRecipient(blocksStaking.address, initialRewardRate);

    console.log('Staking Distributor add Recipient\n');



    // await bondTeller.setFEReward(initFeReward);

    // console.log('Bond Teller set Reward Rate\n');



    // Set Teller address
    await blocksBondDepository.setTeller(bondTeller.address);

    console.log('BLOCKS Bond Depository set Teller\n');



    // Add bond
    await blocksBondDepository.addBond(tdai.address, zeroAddress, initCapacity, false);

    console.log('BLOCKS Bond Depository add Bond\n');



    // Set Term
    await blocksBondDepository.setTerms(0, daiBondBCV, fixedTerm, bondVestingLength, expiration, conclusion, minBondPrice, maxBondPayout, maxBondDebt, intialBondDebt);

    console.log('BLOCKS Bond Depository set Terms\n');



    await blocksTreasury.queueTimelock("8", distributor.address, zeroAddress);
    console.log('BLOCKS Treasury Queue Time Lock 8\n');
    await blocksTreasury.queueTimelock("0", deployer.address, zeroAddress);
    console.log('BLOCKS Treasury Queue Time Lock 0\n');
    await blocksTreasury.queueTimelock("4", deployer.address, zeroAddress);
    console.log('BLOCKS Treasury Queue Time Lock 4\n');
    // await blocksTreasury.queueTimelock("9", sblocks.address, zeroAddress);
    // console.log('BLOCKS Treasury Queue Time Lock 9\n');



    await blocksTreasury.execute(0);
    console.log('BLOCKS Treasury Execute 0\n');
    await blocksTreasury.execute(1);
    console.log('BLOCKS Treasury Execute 1\n');
    await blocksTreasury.execute(2);
    console.log('BLOCKS Treasury Execute 2\n');
    // await blocksTreasury.execute(3);
    // console.log('BLOCKS Treasury Execute 3\n');



    await blocksTreasury.enableOnChainGovernance();

    console.log('BLOCKS Treasury Enable On Chain Governance\n');



    await blocksTreasury.enable("8", bondTeller.address, zeroAddress);
    console.log('BLOCKS Treasury Enable 8\n');
    await blocksTreasury.enable("2", tdai.address, zeroAddress);
    console.log('BLOCKS Treasury Enable 2\n');
    


    console.log('REACT_APP_TDAI:', '\'' + tdai.address + '\'', ",");
    console.log('REACT_APP_BLOCKS:', '\'' + blocks.address + '\'', ",");

    console.log('DAI_ADDRESS:', '\'' + tdai.address + '\'', ",");
    console.log('BLOCKS_ADDRESS:', '\'' + blocks.address + '\'', ",");
    console.log('SBLOCKS_ADDRESS:', '\'' + sblocks.address + '\'', ",");
    console.log('STAKING_ADDRESS:', '\'' + blocksStaking.address + '\'', ",");
    console.log('STAKING_HELPER_ADDRESS:', '\'' + stakingHelper.address + '\'', ",");
    console.log('TREASURY_ADDRESS:', '\'' + blocksTreasury.address + '\'', ",");
    console.log('TELLER_ADDRESS:', '\'' + bondTeller.address + '\'', ",");



    // Approve the treasury to spend DAI and Frax
    await tdai.approve(blocksTreasury.address, '20000000000000000000000000' );
    console.log('TDAI approve BLOCKS Treasury address\n');



    // Deposit 9,000,000 DAI to treasury, 600,000 OHM gets minted to deployer and 8,400,000 are in treasury as excesss reserves
    await blocksTreasury.deposit("20000000000000000000000000", tdai.address, "94000000000000");
    console.log('BLOCKS Treasury Deposit TDAI\n');

}

main()
    .then(() => process.exit())
    .catch(error => {
        console.error(error);
        process.exit(1);
});